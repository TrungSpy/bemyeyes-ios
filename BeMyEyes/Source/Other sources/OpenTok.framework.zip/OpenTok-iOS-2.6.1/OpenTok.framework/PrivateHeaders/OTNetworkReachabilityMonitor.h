//
//  OTNetworkReachabilityMonitor.h
//  otkit-objc-libs
//
//  Created by Charley Robinson on 5/7/15.
//
//

#import <Foundation/Foundation.h>

@interface OTNetworkReachabilityMonitor : NSObject

+ (instancetype)sharedInstance;

- (void)invalidate;



@end
